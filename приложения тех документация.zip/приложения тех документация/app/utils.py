"""
Модуль вспомогательных функций.
Содержит переиспользуемую бизнес-логику и утилиты.
"""

import secrets
import string

def generate_short_code(length: int = 6) -> str:
    """
    Генерирует случайный короткий код заданной длины.
    
    Args:
        length (int): Длина генерируемого кода (по умолчанию 6)
    
    Returns:
        str: Случайная строка из букв и цифр
    
    Example:
        >>> generate_short_code(6)
        'aBcDeF'
    """
    # Используем буквы (верхний и нижний регистр) и цифры
    characters = string.ascii_letters + string.digits
    
    # Генерация криптографически безопасного случайного кода
    return ''.join(secrets.choice(characters) for _ in range(length))

def create_short_url(short_code: str, base_url: str) -> str:
    """
    Создает полный короткий URL из кода и базового URL.
    
    Args:
        short_code (str): Короткий код
        base_url (str): Базовый URL приложения
    
    Returns:
        str: Полный короткий URL
    
    Example:
        >>> create_short_url('aBcDeF', 'http://localhost:8000')
        'http://localhost:8000/aBcDeF'
    """
    return f"{base_url}/{short_code}"