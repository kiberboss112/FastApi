"""
Модуль CRUD операций (Create, Read, Update, Delete).
Содержит функции для взаимодействия с базой данных.
"""

from sqlalchemy.orm import Session
from . import models, schemas, utils

def create_url(db: Session, url: schemas.URLCreate) -> models.URL:
    """
    Создает новую короткую ссылку в базе данных.
    
    Args:
        db (Session): Сессия базы данных
        url (schemas.URLCreate): Данные для создания URL
    
    Returns:
        models.URL: Созданный объект URL
    """
    # Генерация уникального короткого кода
    short_code = utils.generate_short_code()
    
    # Проверка уникальности кода (повторяем пока не найдем уникальный)
    while get_url_by_short_code(db, short_code):
        short_code = utils.generate_short_code()
    
    # Создание объекта модели для сохранения в БД
    db_url = models.URL(
        original_url=url.original_url,
        short_code=short_code
    )
    
    # Сохранение в базу данных
    db.add(db_url)
    db.commit()
    db.refresh(db_url)  # Обновление объекта данными из БД
    
    return db_url

def get_url_by_short_code(db: Session, short_code: str) -> models.URL:
    """
    Находит активный URL по короткому коду.
    
    Args:
        db (Session): Сессия базы данных
        short_code (str): Короткий код для поиска
    
    Returns:
        models.URL: Найденный объект URL или None
    """
    return db.query(models.URL).filter(
        models.URL.short_code == short_code,
        models.URL.is_active == True
    ).first()

def increment_clicks(db: Session, url: models.URL) -> models.URL:
    """
    Увеличивает счетчик кликов для URL.
    
    Args:
        db (Session): Сессия базы данных
        url (models.URL): Объект URL для обновления
    
    Returns:
        models.URL: Обновленный объект URL
    """
    url.clicks += 1
    db.commit()
    db.refresh(url)
    return url

def get_url_stats(db: Session, short_code: str) -> models.URL:
    """
    Получает статистику по короткой ссылке (включая неактивные).
    
    Args:
        db (Session): Сессия базы данных
        short_code (str): Короткий код для поиска
    
    Returns:
        models.URL: Найденный объект URL или None
    """
    return db.query(models.URL).filter(
        models.URL.short_code == short_code
    ).first()

def get_all_urls(db: Session, skip: int = 0, limit: int = 100):
    """
    Получает все ссылки из базы данных с пагинацией.
    
    Args:
        db (Session): Сессия базы данных
        skip (int): Сколько записей пропустить
        limit (int): Максимальное количество записей
    
    Returns:
        List[models.URL]: Список объектов URL
    """
    return db.query(models.URL).offset(skip).limit(limit).all()