"""
Модуль конфигурации базы данных.
Настройка подключения к БД, создание сессий и управление соединениями.
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# URL подключения к базе данных (SQLite для разработки)
SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./shortener.db")

# Создание движка базы данных
# check_same_thread=False необходим для работы SQLite с FastAPI
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, 
    connect_args={"check_same_thread": False}
)

# Создание фабрики сессий для работы с БД
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Базовый класс для всех моделей SQLAlchemy
Base = declarative_base()

def get_db():
    """
    Dependency для FastAPI.
    Генерирует сессию БД для каждого запроса и гарантирует ее закрытие.
    """
    db = SessionLocal()
    try:
        yield db  # Сессия передается в эндпоинт
    finally:
        db.close()  # Сессия закрывается после обработки запроса