"""
Модуль Pydantic схем для валидации данных.
Схемы определяют структуру запросов и ответов API.
"""

from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class URLBase(BaseModel):
    """
    Базовая схема URL.
    Содержит только оригинальный URL.
    """
    original_url: str

class URLCreate(URLBase):
    """
    Схема для создания новой короткой ссылки.
    Наследуется от URLBase.
    """
    pass

class URL(URLBase):
    """
    Схема ответа с полной информацией о URL.
    Используется при возврате данных из БД.
    """
    id: int
    short_code: str
    clicks: int
    created_at: datetime
    is_active: bool
    
    class Config:
        """
        Конфигурация Pydantic для работы с ORM.
        Позволяет создавать экземпляры схем из объектов SQLAlchemy.
        """
        from_attributes = True

class URLInfo(URL):
    """
    Расширенная схема с полным коротким URL.
    Наследует все поля от URL и добавляет short_url.
    """
    short_url: str

class URLStats(URLInfo):
    """
    Схема для статистики ссылки.
    Может быть расширена дополнительными полями статистики.
    """
    pass