"""
Модуль моделей базы данных.
Определяет структуру таблиц и отношения между сущностями.
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean
from .database import Base
from datetime import datetime

class URL(Base):
    """
    Модель для хранения информации о сокращенных URL.
    Соответствует таблице 'urls' в базе данных.
    """
    
    __tablename__ = "urls"  # Имя таблицы в БД
    
    # Первичный ключ, автоинкремент
    id = Column(Integer, primary_key=True, index=True)
    
    # Оригинальный URL (обязательное поле)
    original_url = Column(String, nullable=False)
    
    # Уникальный короткий код для редиректа
    short_code = Column(String, unique=True, index=True, nullable=False)
    
    # Дата и время создания записи
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Счетчик переходов по ссылке
    clicks = Column(Integer, default=0)
    
    # Флаг активности ссылки
    is_active = Column(Boolean, default=True)