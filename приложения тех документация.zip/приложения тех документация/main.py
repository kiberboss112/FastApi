"""
Основной модуль FastAPI приложения.
Определяет эндпоинты API, middleware и конфигурацию приложения.
"""

from fastapi import FastAPI, Depends, HTTPException, status  # ✅ Исправлено
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session  # ✅ Исправлено
from typing import List
import os

from app import crud, models, schemas, utils
from app.database import engine, get_db

# Создание таблиц в базе данных
models.Base.metadata.create_all(bind=engine)

# Создание экземпляра FastAPI приложения
app = FastAPI(
    title="URL Shortener API",
    description="🚀 Современный сервис для сокращения длинных URL-адресов. "
                "Аналогично bit.ly, но с открытым API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Базовый URL из переменных окружения
BASE_URL = os.getenv("BASE_URL", "http://localhost:8000")

@app.post("/shorten/", 
          response_model=schemas.URLInfo,
          summary="Создать короткую ссылку",
          description="Создает короткую версию для длинного URL",
          tags=["Основные операции"])
def create_short_url(
    url: schemas.URLCreate,
    db: Session = Depends(get_db)
):
    """
    Создает короткую ссылку для предоставленного URL.
    
    - **original_url**: Оригинальный длинный URL (обязательный)
    """
    # Создание URL в базе данных
    db_url = crud.create_url(db=db, url=url)
    
    # Формирование ответа
    return {
        **schemas.URL.from_orm(db_url).dict(),
        "short_url": utils.create_short_url(db_url.short_code, BASE_URL)
    }

@app.get("/{short_code}",
         summary="Перейти по короткой ссылке",
         description="Перенаправляет на оригинальный URL",
         tags=["Редирект"])
def redirect_to_original(
    short_code: str,
    db: Session = Depends(get_db)
):
    """
    Перенаправляет на оригинальный URL по короткому коду.
    
    - **short_code**: 6-символьный короткий код (обязательный)
    """
    # Поиск URL в базе данных
    db_url = crud.get_url_by_short_code(db, short_code)
    
    if not db_url:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,  # ✅ Теперь status доступен
            detail="Ссылка не найдена или деактивирована"
        )
    
    # Увеличение счетчика кликов
    crud.increment_clicks(db, db_url)
    
    # Редирект на оригинальный URL
    return RedirectResponse(url=db_url.original_url, status_code=307)

@app.get("/stats/{short_code}",
         response_model=schemas.URLStats,
         summary="Получить статистику ссылки",
         description="Возвращает информацию и статистику по короткой ссылке",
         tags=["Статистика"])
def get_url_statistics(
    short_code: str,
    db: Session = Depends(get_db)
):
    """
    Получает статистику по короткой ссылке.
    
    - **short_code**: 6-символьный короткий код (обязательный)
    """
    db_url = crud.get_url_stats(db, short_code)
    
    if not db_url:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,  # ✅ Теперь status доступен
            detail="Ссылка не найдена"
        )
    
    return {
        **schemas.URL.from_orm(db_url).dict(),
        "short_url": utils.create_short_url(db_url.short_code, BASE_URL)
    }

@app.get("/admin/urls/",
         response_model=List[schemas.URLStats],
         summary="Список всех ссылок",
         description="Возвращает все созданные ссылки",
         tags=["Администрирование"])
def get_all_urls(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    Получает список всех сокращенных ссылок.
    
    - **skip**: Количество записей для пропуска (по умолчанию 0)
    - **limit**: Максимальное количество записей (по умолчанию 100)
    """
    # Ограничение максимального лимита
    if limit > 1000:
        limit = 1000
        
    urls = crud.get_all_urls(db, skip=skip, limit=limit)
    
    return [
        {
            **schemas.URL.from_orm(url).dict(),
            "short_url": utils.create_short_url(url.short_code, BASE_URL)
        }
        for url in urls
    ]

@app.get("/", 
         summary="Информация о API",
         description="Возвращает основную информацию о API",
         tags=["Информация"])
def read_root():
    """
    Корневой эндпоинт API.
    """
    return {
        "message": "Добро пожаловать в URL Shortener API!",
        "version": "1.0.0",
        "documentation": {
            "swagger": "/docs",
            "redoc": "/redoc"
        },
        "endpoints": {
            "create_short_url": "POST /shorten/",
            "redirect": "GET /{short_code}",
            "get_stats": "GET /stats/{short_code}",
            "admin_list": "GET /admin/urls/"
        }
    }

# Точка входа для запуска сервера
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
